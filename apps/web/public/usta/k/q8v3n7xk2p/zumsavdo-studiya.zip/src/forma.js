/**
 * ZumSavdo kengaytmasi — sotuvchi kabinetida «Avtomatik joylash».
 *
 * QANDAY ISHLAYDI
 *  Forma CSS klasslariga emas, maydon YORLIQLARIGA qarab to'ldiriladi
 *  ("Nomi", "Название", "IKPU", "Цена"...). Marketpleys formani qayta
 *  bezasa ham yorliqlar odatda o'zgarmaydi, shuning uchun to'ldirish ishlashda
 *  davom etadi. Yorliq lug'atda topilmasa — o'xshashlik bo'yicha moslash
 *  (sun'iy intellekt o'rnidagi tezkor usul; server modeli ulanganda shu joy
 *  `moslaAI` ga almashadi). Shunda ham topilmasa — maydon qizil bilan
 *  belgilanadi va yon panelda nusxa olish tugmasi bilan ko'rsatiladi.
 *
 *  Adapterlar: UMUMIY (istalgan marketpleys) + UZUM (til tablari, o'ziga xos
 *  yorliqlar). Yangi marketpleys: ADAPTERLAR ga yozuv.
 *
 *  Kengaytma HECH QACHON o'zi yubormaydi — yuborishni foydalanuvchi bosadi.
 */
(function () {
  if (window.__zsForma || window.top !== window) return;
  window.__zsForma = true;

  // ------------------------------------------------------------ marketpleys
  function mpAniqla() {
    const h = location.hostname;
    if (/\/demo\/forma/.test(location.pathname)) return new URLSearchParams(location.search).get("mp") || "uzum";
    if (/uzum\.uz$/.test(h)) return "uzum";
    if (/market\.yandex|yandex\.(ru|uz)$/.test(h)) return "yandex";
    if (/wildberries|wb\.ru$/.test(h)) return "wb";
    return "uzum";
  }
  const MP = mpAniqla();
  const MP_NOM = { uzum: "Uzum Market", yandex: "Yandex Market", wb: "Wildberries" }[MP];

  // --------------------------------------------------------------- lug'at
  const nrm = (s) => String(s || "").toLowerCase().replace(/[ʻʼ’‘`´]/g, "'").replace(/ё/g, "е").replace(/[*:()\[\]]/g, " ").replace(/\s+/g, " ").trim();

  /** Maydon kaliti → yorliqda uchraydigan so'zlar (uz, ru, en). Eng uzun mos kelgani g'olib. */
  const LUGAT = {
    nom: ["nomi", "nom", "mahsulot nomi", "tovar nomi", "название", "наименование", "название товара", "product name", "title", "name"],
    qisqa: ["qisqa tavsif", "qisqacha", "краткое описание", "short description", "анонс"],
    tavsif: ["tavsif", "to'liq tavsif", "mahsulot tavsifi", "описание", "description"],
    kat: ["kategoriya", "turkum", "категория", "предмет", "category", "раздел каталога"],
    ikpu: ["ikpu", "mxik", "икпу", "мхик", "ikpu kodi", "классификатор"],
    brend: ["brend", "brand", "бренд", "tovar belgisi", "торговая марка"],
    mamlakat: ["mamlakat", "kelib chiqish", "страна", "country"],
    ogirlik: ["og'irlik", "og'irligi", "vazn", "вес", "weight", "масса"],
    uzunlik: ["uzunlik", "uzunligi", "длина", "length"],
    eni: ["eni", "kenglik", "ширина", "width"],
    balandlik: ["balandlik", "balandligi", "высота", "height"],
    kalit: ["kalit so'z", "teglar", "qidiruv teg", "ключевые слова", "теги", "keywords", "поисковые запросы"],
    material: ["material", "materiali", "tarkibi", "tarkib", "материал", "состав"],
    narx: ["narx", "sotuv narxi", "цена", "price", "розничная цена", "стоимость"],
    eski_narx: ["chegirmasiz", "eski narx", "до скидки", "без скидки", "старая цена", "зачеркнутая"],
    qoldiq: ["qoldiq", "ombordagi soni", "остаток", "количество", "stock", "quantity"],
    sku: ["sku", "artikul", "артикул", "баркод", "код продавца"],
    rang: ["rang", "rangi", "цвет", "color", "colour"],
    olcham: ["o'lcham", "o'lchami", "размер", "size"],
    rasm: ["rasm", "surat", "фото", "изображен", "медиа", "image", "photo"],
  };
  const TIL = { uz: ["uz", "o'zbek", "узб", "uzb", "ўзб"], ru: ["ru", "рус", "rus"] };

  function lugatMos(yorliq, kalitlar) {
    const y = " " + nrm(yorliq) + " ";
    let eng = null, ball = 0;
    for (const [k, sozlar] of Object.entries(kalitlar)) {
      for (const s of sozlar) {
        const n = nrm(s);
        const ok = n.length <= 3 ? new RegExp(`(^|[^a-zа-я'])${n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^a-zа-я']|$)`).test(y) : y.includes(n);
        if (ok && n.length > ball) { eng = k; ball = n.length; }
      }
    }
    return eng;
  }

  /** O'xshashlik (Dice, harf juftliklari) — lug'atda yo'q yorliqlar uchun. */
  function dice(a, b) {
    a = nrm(a); b = nrm(b);
    if (a.length < 2 || b.length < 2) return 0;
    const m = new Map();
    for (let i = 0; i < a.length - 1; i++) { const p = a.slice(i, i + 2); m.set(p, (m.get(p) || 0) + 1); }
    let o = 0;
    for (let i = 0; i < b.length - 1; i++) { const p = b.slice(i, i + 2); const c = m.get(p); if (c) { o++; m.set(p, c - 1); } }
    return (2 * o) / (a.length + b.length - 2);
  }
  function moslaAI(yorliq, kalitlar) {
    let eng = null, b = 0;
    for (const [k, sozlar] of Object.entries(kalitlar)) for (const s of sozlar) { const d = dice(yorliq, s); if (d > b) { b = d; eng = k; } }
    return b >= 0.62 ? eng : null;
  }

  function tilAniqla(yorliq) {
    const y = " " + nrm(yorliq).replace(/[^a-zа-яў' ]/g, " ") + " ";
    for (const [t, sozlar] of Object.entries(TIL)) if (sozlar.some((s) => (s.length <= 3 ? y.includes(" " + s + " ") : y.includes(s)))) return t;
    return null;
  }

  // ------------------------------------------------------------ DOM yordam
  const korinadimi = (el) => !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length) && getComputedStyle(el).visibility !== "hidden";
  const matnOl = (el) => (el ? (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim() : "");
  const kut = (ms) => new Promise((r) => setTimeout(r, ms));
  const BOSHQARUV = 'input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=submit]):not([type=button]):not([type=file]):not([type=search]), textarea, select, [contenteditable="true"], [contenteditable=""]';

  function yorliqOl(el) {
    const q = [];
    if (el.labels && el.labels.length) q.push([...el.labels].map(matnOl).join(" "));
    const lb = el.getAttribute("aria-labelledby");
    if (lb) q.push(lb.split(/\s+/).map((id) => matnOl(document.getElementById(id))).join(" "));
    if (el.getAttribute("aria-label")) q.push(el.getAttribute("aria-label"));
    const td = el.closest("td");
    if (td) {
      const tr = td.parentElement, table = td.closest("table");
      const i = [...tr.children].indexOf(td);
      const th = table && table.querySelector("thead tr") ? table.querySelector("thead tr").children[i] : null;
      if (th) q.push(matnOl(th));
    }
    if (!q.join("").trim()) {
      // Eng yaqin o'ram: ichida faqat shu boshqaruv bor ota element matni
      let p = el.parentElement;
      for (let d = 0; p && d < 5; d++, p = p.parentElement) {
        if (p.querySelectorAll(BOSHQARUV).length > 1) break;
        const t = matnOl(p).replace(el.value || "", "").trim();
        if (t && t.length < 140) { q.push(t); break; }
      }
    }
    if (el.placeholder) q.push(el.placeholder);
    return q.filter(Boolean).join(" · ").slice(0, 200);
  }

  function majburiymi(el) {
    if (el.required || el.getAttribute("aria-required") === "true") return true;
    const labs = el.labels ? [...el.labels] : [];
    const lb = el.getAttribute("aria-labelledby");
    if (lb) lb.split(/\s+/).forEach((id) => { const x = document.getElementById(id); if (x) labs.push(x); });
    return labs.some((l) => /\*\s*$/.test(matnOl(l)) || (getComputedStyle(l, "::after").content || "").includes("*"));
  }

  function qiymatQoy(el, v, blurYoq) {
    v = v == null ? "" : String(v);
    el.scrollIntoView({ block: "center", behavior: "instant" });
    el.focus();
    if (el.isContentEditable) {
      el.textContent = v;
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: v }));
    } else if (el.tagName === "SELECT") {
      const opts = [...el.options];
      const vs = v.split("|");
      let eng = null, b = 0;
      for (const o of opts) for (const x of vs) {
        const d = nrm(o.text) === nrm(x) ? 2 : dice(o.text, x);
        if (d > b) { b = d; eng = o; }
      }
      if (!eng || b < 0.5) return false;
      el.value = eng.value;
      el.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
    if (!blurYoq) el.dispatchEvent(new Event("blur", { bubbles: true }));
    return true;
  }

  const bosh = (el) => (el.isContentEditable ? !matnOl(el) : !String(el.value || "").trim());

  function belgila(el, yoqmi) {
    const t = el.isContentEditable || el.tagName !== "INPUT" ? el : el;
    if (yoqmi) { t.dataset.zsOld = t.style.boxShadow; t.style.boxShadow = "0 0 0 2px #e5262b, 0 0 0 5px rgba(229,38,43,.18)"; t.dataset.zsBelgi = "1"; }
    else if (t.dataset.zsBelgi) { t.style.boxShadow = t.dataset.zsOld || ""; delete t.dataset.zsBelgi; }
  }

  async function bosVaKut(el, ms = 120) {
    el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    el.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
    el.click();
    await kut(ms);
  }

  // ----------------------------------------------------- qiymatlar (kartadan)
  function qiymatlar(k, til) {
    const xus = {};
    for (const x of k.xususiyatlar || []) xus[nrm(x.k.uz)] = x.v[til] || x.v.uz;
    const xusQidir = (sozlar) => {
      for (const x of k.xususiyatlar || []) {
        if (sozlar.some((s) => nrm(x.k.uz).includes(nrm(s)) || nrm(x.k.ru).includes(nrm(s)))) return x.v[til] || x.v.uz;
      }
      return null;
    };
    const tavsif = k.tavsif[til] + (k.xususiyatlar && k.xususiyatlar.length ? "\n\n" + k.xususiyatlar.map((x) => `• ${x.k[til]}: ${x.v[til]}`).join("\n") : "");
    return {
      nom: k.nom[til],
      qisqa: k.qisqa_tavsif[til],
      tavsif,
      kat: k.kategoriya,
      ikpu: k.ikpu,
      brend: k.brend,
      mamlakat: `${k.mamlakat.uz}|${k.mamlakat.ru}`,
      ogirlik: k.ogirlik_kg,
      uzunlik: k.gabarit_sm.u,
      eni: k.gabarit_sm.e,
      balandlik: k.gabarit_sm.b,
      kalit: (k.kalit_sozlar || []).join(", "),
      material: xusQidir(LUGAT.material),
      narx: k.variantlar[0] && k.variantlar[0].narx,
      eski_narx: k.variantlar[0] && k.variantlar[0].eski_narx,
      qoldiq: k.variantlar[0] && k.variantlar[0].qoldiq,
      sku: k.variantlar[0] && k.variantlar[0].sku,
      rang: k.variantlar[0] && k.variantlar[0].rang ? k.variantlar[0].rang[til] : null,
      olcham: k.variantlar[0] && k.variantlar[0].olcham,
      _xus: k.xususiyatlar || [],
    };
  }

  const MAYDON_NOM = {
    nom: "Nomi", qisqa: "Qisqa tavsif", tavsif: "Tavsif", kat: "Kategoriya", ikpu: "IKPU kodi", brend: "Brend", mamlakat: "Mamlakat",
    ogirlik: "Og'irlik", uzunlik: "Uzunlik", eni: "Eni", balandlik: "Balandlik", kalit: "Kalit so'zlar", material: "Material",
    narx: "Narx", eski_narx: "Eski narx", qoldiq: "Qoldiq", sku: "SKU", rang: "Rang", olcham: "O'lcham", rasm: "Rasmlar", variant: "Variantlar",
  };

  // ------------------------------------------------------------ kategoriya
  async function kategoriyaQoy(el, yol) {
    if (!yol || !yol.length) return false;
    const oxirgi = yol[yol.length - 1];
    if (el.tagName === "SELECT") return qiymatQoy(el, yol.slice().reverse().join("|"));
    qiymatQoy(el, oxirgi, true);
    el.focus();
    el.dispatchEvent(new Event("focus", { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "ArrowDown" }));
    for (let i = 0; i < 8; i++) {
      await kut(200);
      const opts = [...document.querySelectorAll('[role="option"], .ant-select-item-option, [class*="option"]')].filter(korinadimi);
      if (!opts.length) continue;
      let eng = null, b = 0;
      for (const o of opts) {
        const t = matnOl(o);
        let d = dice(t, oxirgi) + (nrm(t).startsWith(nrm(oxirgi)) ? 1 : 0);
        for (const ota of yol.slice(0, -1)) if (nrm(t).includes(nrm(ota))) d += 0.3;
        if (d > b) { b = d; eng = o; }
      }
      if (eng && b >= 0.6) { await bosVaKut(eng, 150); return true; }
    }
    return false;
  }

  // -------------------------------------------------------------- rasmlar
  async function faylga(src, i) {
    let data = src;
    if (!src.startsWith("data:")) {
      const r = await chrome.runtime.sendMessage({ tur: "rasmOl", url: src });
      if (!r || !r.ok) throw new Error("Rasm yuklanmadi");
      data = r.data;
    }
    const b = await (await fetch(data)).blob();
    const ext = b.type.includes("png") ? "png" : "jpg";
    return new File([b], `zumsavdo-${String(i + 1).padStart(2, "0")}.${ext}`, { type: b.type || "image/jpeg" });
  }

  async function rasmlarniQoy(rasmlar) {
    const inputs = [...document.querySelectorAll('input[type="file"]')].filter((x) => !x.closest("#zumsavdo-forma"));
    if (!inputs.length || !rasmlar.length) return false;
    // Rasm uchun mo'ljallanganini tanlash: accept=image yoki yorlig'ida "rasm/фото"
    const inp = inputs.find((x) => /image/.test(x.accept || "")) || inputs.find((x) => lugatMos(yorliqOl(x), { rasm: LUGAT.rasm })) || inputs[0];
    const fayllar = [];
    for (let i = 0; i < rasmlar.length; i++) { try { fayllar.push(await faylga(rasmlar[i], i)); } catch { /* bitta rasm o'tkazib yuboriladi */ } }
    if (!fayllar.length) return false;
    const dt = new DataTransfer();
    (inp.multiple ? fayllar : fayllar.slice(0, 1)).forEach((f) => dt.items.add(f));
    inp.files = dt.files;
    inp.dispatchEvent(new Event("input", { bubbles: true }));
    inp.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  // ------------------------------------------------------------- variantlar
  const VARIANT_KALIT = { rang: LUGAT.rang, olcham: LUGAT.olcham, narx: LUGAT.narx, eski_narx: LUGAT.eski_narx, qoldiq: LUGAT.qoldiq, sku: LUGAT.sku };

  async function variantJadvali(k, til, natija) {
    const jadvallar = [...document.querySelectorAll("table")].filter((t) => !t.closest("#zumsavdo-forma") && korinadimi(t));
    for (const t of jadvallar) {
      const th = t.querySelector("thead tr");
      if (!th) continue;
      const ustun = [...th.children].map((c) => lugatMos(matnOl(c), VARIANT_KALIT));
      if (ustun.filter(Boolean).length < 2 || !ustun.includes("narx")) continue;
      const tb = t.tBodies[0] || t;
      const qoshTugma = [...(t.closest("section, .sec, form, div")?.querySelectorAll("button") || [])].find((b) => /qo'?shish|добавить|add|\+/.test(nrm(matnOl(b))) && !t.contains(b));
      const v = k.variantlar;
      for (let i = 0; i < v.length; i++) {
        let qator = tb.rows[i];
        if (!qator && qoshTugma) { await bosVaKut(qoshTugma, 80); qator = tb.rows[i]; }
        if (!qator) { natija.yoq.push({ maydon: `Variant ${i + 1} (${[v[i].rang && v[i].rang[til], v[i].olcham].filter(Boolean).join(", ")})`, majburiy: true }); continue; }
        [...qator.cells].forEach((c, j) => {
          const kal = ustun[j];
          const inp = c.querySelector(BOSHQARUV);
          if (!kal || !inp) return;
          const x = { rang: v[i].rang ? v[i].rang[til] : "", olcham: v[i].olcham || "", narx: v[i].narx, eski_narx: v[i].eski_narx || "", qoldiq: v[i].qoldiq, sku: v[i].sku }[kal];
          if (x !== "" && x != null) qiymatQoy(inp, x);
          inp.dataset.zsTold = "1";
        });
      }
      natija.bor.push(`${MAYDON_NOM.variant} (${v.length})`);
      return true;
    }
    return false;
  }

  // ---------------------------------------------------------- til tablari
  function tilTablari() {
    const tabs = [...document.querySelectorAll('[role="tab"], .tabs button, [class*="tab"] button, [class*="Tab"]')].filter((x) => korinadimi(x) && !x.closest("#zumsavdo-forma"));
    const uz = tabs.find((x) => /^(uz|o'?zbek|узб|ўзб)/.test(nrm(matnOl(x))));
    const ru = tabs.find((x) => /^(ru|рус)/.test(nrm(matnOl(x))));
    return uz && ru ? { uz, ru } : null;
  }

  // ---------------------------------------------------------- asosiy oqim
  /** Ko'rinib turgan maydonlarni to'ldiradi. `tilMajbur` — til tabi bo'yicha. */
  async function koringanlarniToldir(k, tilMajbur, natija, qayta) {
    const els = [...document.querySelectorAll(BOSHQARUV)].filter((el) => korinadimi(el) && !el.closest("#zumsavdo-forma") && !el.dataset.zsTold && !el.closest("table"));
    const nomlar = els.filter((el) => lugatMos(yorliqOl(el), { nom: LUGAT.nom }) === "nom" && !lugatMos(yorliqOl(el), { brend: LUGAT.brend, kat: LUGAT.kat }));
    for (const el of els) {
      const y = yorliqOl(el);
      const xusKalit = {};
      (k.xususiyatlar || []).forEach((x, i) => { xusKalit["x" + i] = [x.k.uz, x.k.ru]; });
      let kal = lugatMos(y, LUGAT) || lugatMos(y, xusKalit) || moslaAI(y, LUGAT);
      if (!kal) {
        if (majburiymi(el) && bosh(el)) natija.yoq.push({ maydon: y.split(" · ")[0] || "Noma'lum maydon", majburiy: true, el });
        continue;
      }
      let til = tilMajbur || tilAniqla(y);
      if (!til && (kal === "nom" || kal === "tavsif" || kal === "qisqa")) {
        // Yorliqda til yo'q: Uzum — ikki nom maydoni bo'lsa birinchisi uz; boshqa marketpleyslar — ru.
        til = MP === "uzum" ? (nomlar.length > 1 && nomlar.indexOf(el) === 1 ? "ru" : "uz") : "ru";
      }
      til = til || (MP === "uzum" ? "uz" : "ru");
      const q = qayta[til] || (qayta[til] = qiymatlar(k, til));
      let ok = false;
      if (kal.startsWith("x")) {
        const x = k.xususiyatlar[+kal.slice(1)];
        ok = qiymatQoy(el, x.v[til] || x.v.uz);
        kal = "xus:" + x.k.uz;
      } else if (kal === "kat") {
        ok = await kategoriyaQoy(el, q.kat);
      } else if (q[kal] != null && q[kal] !== "") {
        ok = qiymatQoy(el, q[kal]);
      }
      el.dataset.zsTold = "1";
      const nom = kal.startsWith("xus:") ? kal.slice(4) : MAYDON_NOM[kal] + ((kal === "nom" || kal === "tavsif" || kal === "qisqa") ? ` (${til})` : "");
      if (ok) { natija.bor.push(nom); belgila(el, false); }
      else natija.yoq.push({ maydon: nom, majburiy: majburiymi(el), el });
    }
  }

  async function toldir(k) {
    const natija = { bor: [], yoq: [] };
    const qayta = {};
    document.querySelectorAll("[data-zs-told]").forEach((x) => delete x.dataset.zsTold);
    document.querySelectorAll("[data-zs-belgi]").forEach((x) => belgila(x, false));

    await variantJadvali(k, MP === "uzum" ? "uz" : "ru", natija);

    const tabs = tilTablari();
    if (tabs) {
      // UZUM adapteri: til tablari — har tilni o'z tabida to'ldirish
      await bosVaKut(tabs.uz, 200);
      await koringanlarniToldir(k, "uz", natija, qayta);
      await bosVaKut(tabs.ru, 200);
      await koringanlarniToldir(k, "ru", natija, qayta);
      await bosVaKut(tabs.uz, 100);
    } else {
      await koringanlarniToldir(k, null, natija, qayta);
    }

    if (await rasmlarniQoy(k.rasmlar)) natija.bor.push(`${MAYDON_NOM.rasm} (${k.rasmlar.length})`);
    else if (k.rasmlar.length) natija.yoq.push({ maydon: MAYDON_NOM.rasm, majburiy: true });

    // To'ldirilmagan majburiy maydonlarni qizil bilan belgilash
    natija.yoq.forEach((x) => x.el && belgila(x.el, true));
    // Takroriy nomlarni yig'ish
    const korilgan = new Set();
    natija.yoq = natija.yoq.filter((x) => (korilgan.has(x.maydon) ? false : korilgan.add(x.maydon)));
    return natija;
  }

  // ------------------------------------------------ muvaffaqiyatni aniqlash
  const MUVAFFAQIYAT = /(moderatsiyaga yuborildi|tovar (yaratildi|qo'shildi|saqlandi)|товар (создан|добавлен|сохран)|карточка (товара )?создана|отправлен[ао]? на (проверку|модерацию)|успешно (создан|сохран))/i;
  let kuzatuv = null;
  function muvaffaqiyatniKuzat(kalit) {
    if (kuzatuv) kuzatuv.disconnect();
    const tekshir = () => {
      const t = document.body ? document.body.innerText.slice(0, 20000) : "";
      if (MUVAFFAQIYAT.test(t) || /yuborildi=1|success|created/.test(location.search)) {
        kuzatuv.disconnect();
        kuzatuv = null;
        const [id, mp] = kalit.split(":");
        chrome.runtime.sendMessage({ tur: "hisobot", id, mp, joylangan: true, hisobot: { vaqt: new Date().toISOString(), sahifa: location.href, toldirildi: [], toldirilmadi: [], qaytarildi: 0 } });
        panelHolat({ joylandi: true });
      }
    };
    kuzatuv = new MutationObserver(() => { clearTimeout(kuzatuv._t); kuzatuv._t = setTimeout(tekshir, 300); });
    kuzatuv.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  }

  // ================================================================== UI
  const CSS = `
  :host { all: initial; }
  * { box-sizing: border-box; }
  .w { font: 13.5px/1.45 Inter, "Segoe UI", system-ui, sans-serif; color: #0a1a34; }
  .fab { position: fixed; right: 20px; bottom: 84px; z-index: 2147483646; display: inline-flex; align-items: center; gap: 9px; height: 48px; padding: 0 18px 0 8px; border-radius: 99px; border: 0; cursor: pointer; background: #0a1a34; color: #fff; box-shadow: 0 8px 28px rgba(10,26,52,.35); font: 600 14px Inter, "Segoe UI", system-ui, sans-serif; }
  .fab .m { width: 34px; height: 34px; border-radius: 50%; background: #d4e94c; color: #0a1a34; display: grid; place-items: center; font-weight: 900; font-size: 17px; }
  .fab.yoq { display: none; }
  .p { position: fixed; top: 0; right: 0; bottom: 0; width: 380px; max-width: 100vw; z-index: 2147483647; background: #fff; box-shadow: -12px 0 40px rgba(10,26,52,.18); display: none; flex-direction: column; border-left: 1px solid #e3e7ee; }
  .p.on { display: flex; }
  .h { display: flex; align-items: center; gap: 10px; padding: 14px 16px; background: #0a1a34; color: #fff; }
  .h .m { width: 28px; height: 28px; border-radius: 8px; background: #d4e94c; color: #0a1a34; display: grid; place-items: center; font-weight: 900; }
  .h b { flex: 1; font-size: 14.5px; }
  .h small { display: block; color: #a9b6ca; font-weight: 500; font-size: 11.5px; }
  .h button { background: none; border: 0; color: #fff; font-size: 20px; cursor: pointer; width: 30px; height: 30px; border-radius: 8px; }
  .b { flex: 1; overflow: auto; padding: 14px 16px 20px; display: flex; flex-direction: column; gap: 12px; }
  .lbl { font-size: 11.5px; font-weight: 700; color: #7d8ba0; text-transform: uppercase; letter-spacing: .04em; }
  .k { display: flex; gap: 10px; align-items: center; padding: 9px; border: 1px solid #e3e7ee; border-radius: 12px; cursor: pointer; background: #fff; text-align: left; width: 100%; font: inherit; color: inherit; }
  .k.on { border-color: #0a1a34; box-shadow: inset 0 0 0 1px #0a1a34; background: #f6f8fa; }
  .k img { width: 46px; height: 60px; object-fit: cover; border-radius: 8px; background: #eef1f5; flex: none; }
  .k span { display: flex; flex-direction: column; min-width: 0; }
  .k b { font-weight: 600; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
  .k small { color: #7d8ba0; font-size: 11.5px; }
  .k .ogoh { color: #9a5b00; }
  .go { height: 46px; border-radius: 12px; border: 0; background: #d4e94c; color: #0a1a34; font: 700 15px Inter, system-ui, sans-serif; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; }
  .go:disabled { opacity: .5; cursor: default; }
  .sec { border: 1px solid #e3e7ee; border-radius: 12px; padding: 12px; display: flex; flex-direction: column; gap: 8px; }
  .ok { color: #137a3f; font-weight: 600; }
  .bad { color: #b42318; font-weight: 600; }
  .yoq { display: flex; flex-direction: column; gap: 4px; }
  .yoq button { text-align: left; border: 1px solid #f3c1bd; background: #fde8e6; color: #b42318; border-radius: 8px; padding: 6px 9px; font: 600 12.5px Inter, system-ui, sans-serif; cursor: pointer; }
  .yoq button.ixt { border-color: #e3e7ee; background: #f6f8fa; color: #52627a; }
  .n { display: flex; flex-direction: column; gap: 6px; }
  .nr { display: grid; grid-template-columns: 1fr auto; gap: 8px; align-items: start; padding: 7px 9px; border-radius: 8px; background: #f6f8fa; }
  .nr .t { font-size: 11.5px; color: #7d8ba0; }
  .nr .v { font-size: 12.5px; white-space: pre-wrap; max-height: 60px; overflow: hidden; word-break: break-word; }
  .nr button { border: 1px solid #d9dfe8; background: #fff; border-radius: 7px; padding: 4px 8px; font: 600 11.5px Inter, system-ui, sans-serif; cursor: pointer; color: #0a1a34; }
  .nr button.ok2 { background: #e3f4ea; color: #137a3f; border-color: transparent; }
  .eslat { background: #fff3d6; color: #9a5b00; border-radius: 10px; padding: 9px 11px; font-size: 12.5px; }
  .bosh { text-align: center; color: #52627a; padding: 20px 6px; display: flex; flex-direction: column; gap: 10px; align-items: center; }
  .btn2 { height: 36px; padding: 0 14px; border-radius: 10px; border: 1px solid #d9dfe8; background: #fff; font: 600 13px Inter, system-ui, sans-serif; cursor: pointer; color: #0a1a34; }
  .s { width: 16px; height: 16px; border-radius: 50%; border: 2px solid rgba(10,26,52,.25); border-top-color: #0a1a34; animation: r .7s linear infinite; }
  @keyframes r { to { transform: rotate(360deg); } }
  .joy { background: #e3f4ea; color: #137a3f; border-radius: 12px; padding: 14px; text-align: center; font-weight: 700; }
  details summary { cursor: pointer; font-weight: 600; }
  `;

  let sh, tanlangan = null, oxirgiNatija = null, oxirgiKarta = null;

  function el(tag, attrs = {}, ...bolalar) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === "on") Object.entries(v).forEach(([ev, f]) => e.addEventListener(ev, f));
      else if (k === "class") e.className = v;
      else e.setAttribute(k, v);
    }
    bolalar.flat().forEach((b) => b != null && e.append(b.nodeType ? b : document.createTextNode(String(b))));
    return e;
  }

  function nusxa(sarlavha, qiymat) {
    const b = el("button", { on: { click: async () => { await navigator.clipboard.writeText(String(qiymat)); b.textContent = "✓"; b.className = "ok2"; setTimeout(() => { b.textContent = "Nusxa"; b.className = ""; }, 1400); } } }, "Nusxa");
    return el("div", { class: "nr" }, el("div", {}, el("div", { class: "t" }, sarlavha), el("div", { class: "v" }, String(qiymat))), b);
  }

  function nusxaBolim(k) {
    const qatorlar = [
      ["Nomi (UZ)", k.nom.uz], ["Nomi (RU)", k.nom.ru],
      ["Qisqa tavsif (UZ)", k.qisqa_tavsif.uz], ["Qisqa tavsif (RU)", k.qisqa_tavsif.ru],
      ["Tavsif (UZ)", k.tavsif.uz], ["Tavsif (RU)", k.tavsif.ru],
      ["Kategoriya", k.kategoriya.join(" › ")], ["IKPU", k.ikpu], ["Brend", k.brend], ["Mamlakat", `${k.mamlakat.uz} / ${k.mamlakat.ru}`],
      ["Og'irlik, kg", k.ogirlik_kg], ["Gabarit, sm", `${k.gabarit_sm.u} × ${k.gabarit_sm.e} × ${k.gabarit_sm.b}`],
      ["Kalit so'zlar", (k.kalit_sozlar || []).join(", ")],
      ...k.variantlar.map((v, i) => [`Variant ${i + 1}: ${[v.rang && v.rang.uz, v.olcham].filter(Boolean).join(", ") || "asosiy"}`, `narx ${v.narx} · qoldiq ${v.qoldiq} · SKU ${v.sku}`]),
      ...(k.xususiyatlar || []).map((x) => [x.k.uz, `${x.v.uz} / ${x.v.ru}`]),
    ].filter((x) => x[1] !== "" && x[1] != null);
    const rasmlar = el("div", { class: "nr" }, el("div", {}, el("div", { class: "t" }, "Rasmlar"), el("div", { class: "v" }, `${k.rasmlar.length} ta, marketpleys o'lchamida`)),
      el("button", { on: { click: () => k.rasmlar.forEach((r, i) => { const a = document.createElement("a"); a.href = r; a.download = `zumsavdo-${i + 1}.jpg`; a.click(); }) } }, "Yuklab olish"));
    return el("details", { class: "sec" }, el("summary", {}, "Qo'lda to'ldirish uchun nusxa olish"), el("div", { class: "n" }, ...qatorlar.map(([a, b]) => nusxa(a, b)), rasmlar));
  }

  async function chiz() {
    const { kartalar = {}, faol, sessiya } = await chrome.storage.local.get(["kartalar", "faol", "sessiya"]);
    const b = sh.getElementById("b");
    b.innerHTML = "";
    if (!sessiya) {
      b.append(el("div", { class: "bosh" }, el("b", {}, "ZumSavdo'ga kiring"), "Kengaytma akkauntingizni ZumSavdo saytida kirganingizda o'zi taniydi.", el("button", { class: "btn2", on: { click: () => chrome.runtime.sendMessage({ tur: "studiyaOch" }) } }, "ZumSavdo'ni ochish")));
      return;
    }
    const royxat = Object.entries(kartalar).sort((a, c) => (a[0] === faol ? -1 : c[0] === faol ? 1 : c[1].vaqt - a[1].vaqt));
    const shu = royxat.filter(([kal]) => kal.endsWith(":" + MP));
    if (!royxat.length) {
      b.append(el("div", { class: "bosh" }, el("b", {}, "Tayyor kartochka yo'q"), "Studiyada mahsulotni tayyorlab, «Joylash» bosqichida «Kabinetda joylash» tugmasini bosing.", el("button", { class: "btn2", on: { click: () => chrome.runtime.sendMessage({ tur: "studiyaOch" }) } }, "Studiyani ochish")));
      return;
    }
    if (!tanlangan || !kartalar[tanlangan]) tanlangan = (shu[0] || royxat[0])[0];
    b.append(el("div", { class: "lbl" }, "Qaysi mahsulot"));
    for (const [kal, k] of royxat.slice(0, 6)) {
      const mp = kal.split(":")[1];
      b.append(el("button", { class: "k" + (kal === tanlangan ? " on" : ""), on: { click: () => { tanlangan = kal; chiz(); } } },
        el("img", { src: k.rasm || "", alt: "" }),
        el("span", {}, el("b", {}, k.nom), el("small", { class: mp !== MP ? "ogoh" : "" }, mp !== MP ? `Bu kartochka ${{ uzum: "Uzum", yandex: "Yandex", wb: "WB" }[mp]} uchun tayyorlangan` : new Date(k.vaqt).toLocaleString("ru-RU")))));
    }
    const go = el("button", { class: "go", on: { click: () => bajar(kartalar[tanlangan], tanlangan) } }, "⚡ Formani to'ldirish");
    b.append(go);
    b.append(el("div", { class: "eslat" }, "Kengaytma faqat to'ldiradi. Tekshirib, marketpleysning o'z «Saqlash / Yuborish» tugmasini o'zingiz bosing."));
    if (oxirgiNatija && oxirgiKarta === tanlangan) natijaChiz(b, oxirgiNatija);
    b.append(nusxaBolim(kartalar[tanlangan].malumot));
  }

  function natijaChiz(b, n) {
    const s = el("div", { class: "sec" });
    s.append(el("div", { class: "ok" }, `✓ ${n.bor.length} ta maydon to'ldirildi`));
    if (n.yoq.length) {
      s.append(el("div", { class: "bad" }, `${n.yoq.length} ta maydonni qo'lda to'ldiring:`));
      s.append(el("div", { class: "yoq" }, ...n.yoq.map((x) => el("button", { class: x.majburiy ? "" : "ixt", on: { click: () => x.el && x.el.scrollIntoView({ block: "center", behavior: "smooth" }) } }, x.maydon + (x.majburiy ? " · majburiy" : "")))));
    } else {
      s.append(el("div", {}, "Hamma maydon to'ldirildi. Endi tekshirib, yuboring."));
    }
    if (n.qaytarildi) s.append(el("div", { class: "ok" }, `${n.qaytarildi} tanga qaytariladi — xato haqida hisobot ZumSavdo'ga yuborildi.`));
    b.append(s);
  }

  function panelHolat(x) {
    if (x.joylandi) {
      const b = sh.getElementById("b");
      b.prepend(el("div", { class: "joy" }, "✓ Joylandi! Studiyada holat «Joylangan» bo'ldi."));
      sh.getElementById("p").classList.add("on");
    }
  }

  async function bajar(karta, kalit) {
    const go = sh.querySelector(".go");
    go.disabled = true;
    go.innerHTML = '<span class="s"></span> To\'ldirilmoqda…';
    let n;
    try {
      n = await toldir(karta.malumot);
    } catch (e) {
      n = { bor: [], yoq: [{ maydon: "Xatolik: " + (e.message || e), majburiy: true }] };
    }
    const majburiyYoq = n.yoq.filter((x) => x.majburiy).length;
    oxirgiNatija = { ...n, qaytarildi: 0 };
    oxirgiKarta = kalit;
    const [id, mp] = kalit.split(":");
    // Hisobot — Studiyaga (tanga qaytarish qarori ilovada: sozlama chegarasi bo'yicha)
    chrome.runtime.sendMessage({
      tur: "hisobot", id, mp, joylangan: false,
      hisobot: { vaqt: new Date().toISOString(), sahifa: location.href, toldirildi: n.bor, toldirilmadi: n.yoq.map((x) => ({ maydon: x.maydon, majburiy: !!x.majburiy })), qaytarildi: 0 },
    });
    if (majburiyYoq > 3) oxirgiNatija.qaytarildi = -1;
    muvaffaqiyatniKuzat(kalit);
    await chiz();
    if (oxirgiNatija.qaytarildi === -1) {
      const b = sh.getElementById("b");
      b.querySelector(".sec")?.append(el("div", { class: "ok" }, "Majburiy maydonlar ko'p to'ldirilmadi — sarflangan tanga qaytariladi, xato hisoboti ZumSavdo'ga yuborildi."));
    }
  }

  function ishga() {
    if (document.getElementById("zumsavdo-forma")) return;
    const host = document.createElement("div");
    host.id = "zumsavdo-forma";
    sh = host.attachShadow({ mode: "open" });
    sh.innerHTML = `<style>${CSS}</style><div class="w"><button class="fab" id="fab"><span class="m">Z</span>Avtomatik joylash</button><div class="p" id="p"><div class="h"><span class="m">Z</span><b>Avtomatik joylash<small>ZumSavdo Studiya · ${MP_NOM}</small></b><button id="x" title="Yopish">×</button></div><div class="b" id="b"></div></div></div>`;
    document.documentElement.appendChild(host);
    sh.getElementById("fab").onclick = () => { sh.getElementById("p").classList.add("on"); sh.getElementById("fab").classList.add("yoq"); chiz(); };
    sh.getElementById("x").onclick = () => { sh.getElementById("p").classList.remove("on"); sh.getElementById("fab").classList.remove("yoq"); };
    chrome.storage.onChanged.addListener((o, joy) => { if (joy === "local" && (o.kartalar || o.faol) && sh.getElementById("p").classList.contains("on")) chiz(); });
    // Studiyadan "Kabinetda joylash" bosilib ochilgan bo'lsa — panel o'zi ochiladi
    chrome.storage.local.get(["faol", "kartalar"]).then(({ faol, kartalar }) => {
      const k = faol && kartalar && kartalar[faol];
      if (k && Date.now() - k.vaqt < 120_000 && faol.endsWith(":" + MP)) sh.getElementById("fab").click();
    });
  }

  ishga();
})();
