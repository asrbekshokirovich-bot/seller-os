/**
 * ZumSavdo kengaytmasi — fon (service worker).
 *
 * Vazifalari:
 *  - Studiya so'ragan havolani foydalanuvchi brauzerida fon tabida ochib o'qish
 *    (foydalanuvchining 1688/Taobao'dagi kirishi ishlatiladi, bot-bloklash yo'q);
 *  - navbatlar: Xitoydan olingan mahsulotlar (xomlar) va forma hisobotlari
 *    Studiya sahifasi ochilganda unga uzatiladi;
 *  - rasmlarni yuklab olish (sahifa CORS bilan ololmaydigan rasmlar);
 *  - zaxira bog'lash kodi.
 *
 * Saqlash (chrome.storage.local): sessiya, xomlar, hisobotlar, kartalar, faol, tarix, kodKutish.
 */

const VERSIYA = chrome.runtime.getManifest().version;
const STANDART_SAYT = "https://zumsavdo.vercel.app/usta/";

const ol = (k) => chrome.storage.local.get(k).then((x) => x[k]);
const qoy = (o) => chrome.storage.local.set(o);
const nid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const kut = (ms) => new Promise((r) => setTimeout(r, ms));

async function navbatQosh(nom, element) {
  const n = (await ol(nom)) || [];
  n.push({ nid: nid(), vaqt: Date.now(), ...element });
  await qoy({ [nom]: n.slice(-50) });
  belgiYangila();
}

/** Studiya tabiga beriladigan elementlar. Berilgan, lekin 30 soniyada tasdiqlanmagani qayta beriladi. */
async function navbatOl(nom) {
  const n = (await ol(nom)) || [];
  const hozir = Date.now();
  const ber = n.filter((x) => !x.berildi || hozir - x.berildi > 30_000);
  if (!ber.length) return [];
  ber.forEach((x) => (x.berildi = hozir));
  await qoy({ [nom]: n });
  return ber;
}

async function navbatTozala(nom, nidlar) {
  const n = (await ol(nom)) || [];
  await qoy({ [nom]: n.filter((x) => !nidlar.includes(x.nid)) });
  belgiYangila();
}

async function belgiYangila() {
  const n = ((await ol("xomlar")) || []).length;
  chrome.action.setBadgeBackgroundColor({ color: "#d4e94c" });
  chrome.action.setBadgeTextColor?.({ color: "#0a1a34" });
  chrome.action.setBadgeText({ text: n ? String(n) : "" });
}

async function saytManzil() {
  const s = await ol("sessiya");
  return (s && s.sayt) || STANDART_SAYT;
}

async function studiyaOch(yol = "#/studiya") {
  const sayt = await saytManzil();
  const tablar = await chrome.tabs.query({});
  const bor = tablar.find((t) => t.url && t.url.startsWith(sayt.replace(/#.*$/, "")) && !t.url.includes("/demo/"));
  if (bor) {
    await chrome.tabs.update(bor.id, { active: true, url: sayt.replace(/#.*$/, "") + yol });
    await chrome.windows.update(bor.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: sayt.replace(/#.*$/, "") + yol });
  }
}

// ------------------------------------------------- havoladan fon tabida olish

function tabTayyor(tabId, ms = 25_000) {
  return new Promise((ok, yoq) => {
    const t = setTimeout(() => { chrome.tabs.onUpdated.removeListener(f); yoq(new Error("Sahifa juda uzoq ochildi")); }, ms);
    function f(id, info) {
      if (id === tabId && info.status === "complete") {
        clearTimeout(t);
        chrome.tabs.onUpdated.removeListener(f);
        ok();
      }
    }
    chrome.tabs.onUpdated.addListener(f);
  });
}

async function havoladanOl(url) {
  let origin;
  try { origin = new URL(url).origin; } catch { return { ok: false, xato: "Havola noto'g'ri" }; }
  const ruxsat = await chrome.permissions.contains({ origins: [origin + "/*"] });
  if (!ruxsat) {
    return { ok: false, xato: "Bu sayt uchun ruxsat yo'q. Sahifani brauzerda ochib, kengaytma oynasidagi «Shu sahifadan olish» tugmasini bosing." };
  }
  const tab = await chrome.tabs.create({ url, active: false });
  try {
    await tabTayyor(tab.id);
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["src/ajratish.js"] });
    // Zamonaviy sahifalar ma'lumotni kechroq chizadi — bir necha marta urinamiz.
    for (let i = 0; i < 4; i++) {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => globalThis.__zsAjrat() });
      const x = r && r.result;
      if (x && !x.xato && (x.rasmlar.length || i === 3)) return { ok: true, xom: x };
      if (x && x.xato === "kirish") return { ok: false, xato: x.matn };
      await kut(1500);
    }
    return { ok: false, xato: "Sahifada mahsulot ma'lumoti topilmadi" };
  } catch (e) {
    return { ok: false, xato: e.message || "Sahifa ochilmadi" };
  } finally {
    chrome.tabs.remove(tab.id).catch(() => {});
  }
}

async function tarixgaQosh(xom) {
  const t = (await ol("tarix")) || [];
  t.unshift({ nom: xom.nom_asl, rasm: xom.rasmlar[0] && xom.rasmlar[0].src, sayt: xom.sayt, vaqt: Date.now(), url: xom.url });
  await qoy({ tarix: t.slice(0, 8) });
}

// ---------------------------------------------------------- rasm yuklab olish

async function rasmOl(url) {
  const r = await fetch(url, { credentials: "omit" });
  if (!r.ok) throw new Error("Rasm yuklanmadi: " + r.status);
  const b = await r.blob();
  const buf = new Uint8Array(await b.arrayBuffer());
  let s = "";
  for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return `data:${b.type || "image/jpeg"};base64,${btoa(s)}`;
}

// ------------------------------------------------------------ bog'lash kodi

let kodKutuvchi = null;

async function kodYubor(kod) {
  const sayt = await saytManzil();
  const tablar = await chrome.tabs.query({});
  if (!tablar.some((t) => t.url && t.url.startsWith(sayt.replace(/#.*$/, "")))) {
    return { ok: false, xato: "ZumSavdo Studiya sahifasini oching (kod o'sha yerda ko'rsatilgan) va qayta urining." };
  }
  await qoy({ kodKutish: { kod, vaqt: Date.now() } });
  const javob = await new Promise((ok) => {
    kodKutuvchi = ok;
    setTimeout(() => ok({ ok: false, xato: "Javob kelmadi. Studiya sahifasini yangilab ko'ring." }), 8000);
  });
  kodKutuvchi = null;
  await chrome.storage.local.remove("kodKutish");
  return javob.ok ? { ok: true } : { ok: false, xato: javob.xato || "Kod noto'g'ri yoki muddati o'tgan" };
}

// ----------------------------------------------------------------- xabarlar

chrome.runtime.onMessage.addListener((x, kimdan, javob) => {
  (async () => {
    switch (x.tur) {
      case "olish":
        return havoladanOl(x.url);
      case "xomQosh":
        await navbatQosh("xomlar", { xom: x.xom });
        await tarixgaQosh(x.xom);
        return { ok: true };
      case "navbatOl":
        return navbatOl(x.navbat);
      case "navbatTozala":
        await navbatTozala(x.navbat, x.nidlar);
        return { ok: true };
      case "hisobot":
        await navbatQosh("hisobotlar", { id: x.id, mp: x.mp, hisobot: x.hisobot, joylangan: !!x.joylangan });
        return { ok: true };
      case "rasmOl":
        try { return { ok: true, data: await rasmOl(x.url) }; } catch (e) { return { ok: false, xato: e.message }; }
      case "studiyaOch":
        await studiyaOch(x.yol);
        return { ok: true };
      case "kodYubor":
        return kodYubor(x.kod);
      case "kodNatija":
        if (kodKutuvchi) kodKutuvchi({ ok: !!x.ok });
        return { ok: true };
      case "sahifadanOl": {
        // Popup: istalgan ochiq sahifadan (activeTab ruxsati bilan)
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab) return { ok: false, xato: "Faol tab topilmadi" };
        try {
          await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["src/ajratish.js"] });
          const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => globalThis.__zsAjrat() });
          const xom = r && r.result;
          if (!xom || xom.xato) return { ok: false, xato: (xom && xom.matn) || "Mahsulot topilmadi" };
          await navbatQosh("xomlar", { xom });
          await tarixgaQosh(xom);
          return { ok: true, nom: xom.nom_asl };
        } catch (e) {
          return { ok: false, xato: "Bu sahifada ishlab bo'lmaydi (" + (e.message || "ruxsat yo'q") + ")" };
        }
      }
      case "tabOch":
        await chrome.tabs.create({ url: x.url, active: true });
        return { ok: true };
      case "versiya":
        return { versiya: VERSIYA };
      default:
        return { ok: false, xato: "Noma'lum so'rov" };
    }
  })().then(javob, (e) => javob({ ok: false, xato: e.message }));
  return true;
});

chrome.runtime.onInstalled.addListener(belgiYangila);
chrome.runtime.onStartup.addListener(belgiYangila);
