/**
 * ZumSavdo kengaytmasi — Studiya sahifasidagi ko'prik.
 *
 * Ilova (zumsavdo.vercel.app/usta) bilan window.postMessage orqali gaplashadi:
 *   ilova → kengaytma: salom, sessiya, olish, karta, qabulQilindi, kodJavob
 *   kengaytma → ilova: salom, xomlar, olindi, olishXato, hisobotlar, kodTekshir
 * Protokol: studiya-kengaytma/README.md, ilova tomoni: ilova/src/studiya/kopruk.ts
 */
(function () {
  if (window.__zsKopruk) return;
  window.__zsKopruk = true;

  const ILOVA = "zumsavdo-ilova";
  const KENGAYTMA = "zumsavdo-kengaytma";
  const versiya = chrome.runtime.getManifest().version;
  const brauzer = /YaBrowser/.test(navigator.userAgent) ? "Yandex Browser" : /Edg\//.test(navigator.userAgent) ? "Edge" : "Chrome";

  const sahifaga = (x) => window.postMessage({ zs: KENGAYTMA, ...x }, location.origin);
  const fonga = (x) => chrome.runtime.sendMessage(x).catch(() => null);

  let tanildi = false;

  async function navbatlarniBer() {
    if (!tanildi || document.visibilityState === "hidden") return;
    const xomlar = await fonga({ tur: "navbatOl", navbat: "xomlar" });
    if (xomlar && xomlar.length) sahifaga({ tur: "xomlar", royxat: xomlar.map((x) => ({ nid: x.nid, xom: x.xom })) });
    const hs = await fonga({ tur: "navbatOl", navbat: "hisobotlar" });
    if (hs && hs.length) sahifaga({ tur: "hisobotlar", royxat: hs.map((x) => ({ nid: x.nid, id: x.id, mp: x.mp, hisobot: x.hisobot, joylangan: x.joylangan })) });
  }

  window.addEventListener("message", async (e) => {
    if (e.source !== window || !e.data || e.data.zs !== ILOVA) return;
    const x = e.data;
    switch (x.tur) {
      case "salom":
        sahifaga({ tur: "salom", versiya, brauzer });
        break;
      case "sessiya":
        tanildi = true;
        await chrome.storage.local.set({ sessiya: { telefon: x.telefon, ism: x.ism, tanga: x.tanga, sayt: x.sayt, vaqt: Date.now() } });
        navbatlarniBer();
        break;
      case "olish": {
        const r = await fonga({ tur: "olish", url: x.url });
        if (r && r.ok) sahifaga({ tur: "olindi", id: x.id, xom: r.xom });
        else sahifaga({ tur: "olishXato", id: x.id, xato: (r && r.xato) || "Kengaytma javob bermadi" });
        break;
      }
      case "karta": {
        const kalit = x.malumot.id + ":" + x.malumot.mp;
        const { kartalar = {} } = await chrome.storage.local.get("kartalar");
        kartalar[kalit] = { malumot: x.malumot, nom: x.nom, rasm: x.rasm, vaqt: Date.now() };
        // eng ko'pi 12 ta oxirgi kartochka saqlanadi (rasmlar og'ir)
        const kalitlar = Object.keys(kartalar).sort((a, b) => kartalar[b].vaqt - kartalar[a].vaqt);
        kalitlar.slice(12).forEach((k) => delete kartalar[k]);
        await chrome.storage.local.set({ kartalar, faol: kalit });
        if (x.och) await fonga({ tur: "tabOch", url: x.och });
        break;
      }
      case "qabulQilindi":
        await fonga({ tur: "navbatTozala", navbat: x.navbat, nidlar: x.nidlar });
        break;
      case "kodJavob":
        await fonga({ tur: "kodNatija", ok: x.ok });
        break;
    }
  });

  chrome.storage.onChanged.addListener((o, joy) => {
    if (joy !== "local") return;
    if (o.xomlar || o.hisobotlar) navbatlarniBer();
    if (o.kodKutish && o.kodKutish.newValue) sahifaga({ tur: "kodTekshir", kod: o.kodKutish.newValue.kod });
  });
  document.addEventListener("visibilitychange", navbatlarniBer);

  // Kod sessiyadan oldin kutilayotgan bo'lsa
  chrome.storage.local.get("kodKutish").then(({ kodKutish }) => {
    if (kodKutish && Date.now() - kodKutish.vaqt < 10_000) sahifaga({ tur: "kodTekshir", kod: kodKutish.kod });
  });

  sahifaga({ tur: "salom", versiya, brauzer });
})();
