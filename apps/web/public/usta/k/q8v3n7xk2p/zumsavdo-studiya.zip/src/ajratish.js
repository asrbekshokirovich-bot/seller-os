/**
 * ZumSavdo kengaytmasi — Xitoy sahifasidan mahsulot ma'lumotini ajratish.
 *
 * Sahifa ichida ishlaydi (kontent skript yoki fon tabida executeScript).
 * Natija: Studiyaning XomMahsulot shakli (ilova/src/data/studiya-turlar.ts).
 *
 * Har sayt uchun bir nechta yo'l bor: avval sahifa ichidagi JSON (eng aniq),
 * keyin DOM, oxirida umumiy usul (JSON-LD, og: teglari, eng katta rasmlar).
 * Sayt dizayni o'zgarsa ham umumiy usul biror natija beradi; bunday holatda
 * `ishonch: "past"` qaytadi va Studiya foydalanuvchiga tekshirishni aytadi.
 */
(function () {
  if (globalThis.__zsAjrat) return;

  const matn = (el) => (el ? (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim() : "");
  const birinchi = (...sel) => {
    for (const s of sel) {
      const el = document.querySelector(s);
      if (el && matn(el)) return el;
    }
    return null;
  };
  const sonOl = (t) => {
    if (t == null) return null;
    const m = String(t).replace(/,/g, "").match(/\d+(?:\.\d+)?/);
    return m ? Number(m[0]) : null;
  };

  /** Rasm manzilini to'liq o'lchamga keltirish (alicdn: _400x400.jpg kabi qo'shimchalarni olib tashlash). */
  function rasmToza(u) {
    if (!u || typeof u !== "string") return null;
    u = u.trim();
    if (u.startsWith("data:")) return null;
    if (u.startsWith("//")) u = "https:" + u;
    if (!/^https?:/i.test(u)) {
      try { u = new URL(u, location.href).href; } catch { return null; }
    }
    if (/alicdn\.com|aliexpress-media\.com/.test(u)) {
      u = u.replace(/(\.(?:jpe?g|png|webp))_\d+x\d+[^/]*$/i, "$1").replace(/_\d+x\d+(q\d+)?\.(jpe?g|png|webp)(_\.webp)?$/i, "");
    }
    if (/pddpic\.com|yangkeduo/.test(u)) u = u.split("?")[0];
    return u;
  }
  const yagona = (arr) => {
    const s = new Set();
    return arr.filter((x) => x && !s.has(x) && s.add(x));
  };

  function skriptJson(regex) {
    for (const s of document.scripts) {
      const t = s.textContent || "";
      if (!t || t.length < 50) continue;
      const m = t.match(regex);
      if (!m) continue;
      try {
        return JSON.parse(m[1]);
      } catch {
        // oxiridagi ortiqcha belgilarni kesib ko'ramiz
        const raw = m[1];
        for (let i = raw.length; i > raw.length - 400 && i > 0; i--) {
          if (raw[i - 1] !== "}") continue;
          try { return JSON.parse(raw.slice(0, i)); } catch { /* davom */ }
        }
      }
    }
    return null;
  }

  function jsonLdProduct() {
    for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        const d = JSON.parse(s.textContent);
        const arr = Array.isArray(d) ? d : d["@graph"] || [d];
        const p = arr.find((x) => x && /Product/i.test(String(x["@type"])));
        if (p) return p;
      } catch { /* e'tiborsiz */ }
    }
    return null;
  }

  function kattaRasmlar(limit = 12) {
    return yagona(
      [...document.images]
        .filter((im) => (im.naturalWidth || im.width) >= 280 && (im.naturalHeight || im.height) >= 280)
        .sort((a, b) => b.naturalWidth * b.naturalHeight - a.naturalWidth * a.naturalHeight)
        .map((im) => rasmToza(im.currentSrc || im.src)),
    ).slice(0, limit);
  }

  function natija(sayt, d) {
    const rasmlar = yagona((d.rasmlar || []).map((r) => (typeof r === "string" ? rasmToza(r) : rasmToza(r.src))))
      .slice(0, 20)
      .map((src) => {
        const asl = (d.rasmlar || []).find((r) => typeof r !== "string" && rasmToza(r.src) === src);
        return { src, ieroglif: !!(asl && asl.ieroglif), suv_belgi: !!(asl && asl.suv_belgi) };
      });
    const ranglar = d.ranglar || [];
    const olchamlar = d.olchamlar || [];
    return {
      url: kanonik(),
      sayt,
      nom_asl: (d.nom || document.title || "").trim().slice(0, 300),
      tavsif_asl: (d.tavsif || "").trim().slice(0, 3000),
      narx_yuan: d.narx || 0,
      narx_oraliq: d.oraliq || undefined,
      min_buyurtma: d.min || undefined,
      dokon: d.dokon || undefined,
      turkum_asl: d.turkum || undefined,
      xususiyatlar_asl: (d.xus || []).filter((x) => x.k && x.v).slice(0, 40),
      ranglar_asl: ranglar,
      olchamlar_asl: olchamlar,
      variantlar_asl: d.variantlar || [],
      rasmlar,
      olcham_jadvali: d.olchamJadval || undefined,
      ogirlik_kg: d.ogirlik || undefined,
      olindi: new Date().toISOString(),
      usul: "kengaytma",
      ishonch: d.ishonch || "yuqori",
    };
  }

  function kanonik() {
    const c = document.querySelector('link[rel="canonical"]');
    const u = (c && c.href) || location.href;
    try {
      const x = new URL(u);
      // kuzatuv parametrlarini olib tashlash, mahsulot id sini qoldirish
      const keep = ["id", "goods_id", "offerId"];
      [...x.searchParams.keys()].forEach((k) => { if (!keep.includes(k)) x.searchParams.delete(k); });
      return x.href;
    } catch { return u; }
  }

  // ---------------------------------------------------------------- 1688
  function s1688() {
    const init = skriptJson(/window\.__INIT_DATA\s*=\s*(\{[\s\S]*\})\s*;?\s*$/m) || skriptJson(/window\.__INIT_DATA\s*=\s*(\{[\s\S]*?\});/);
    const g = init && (init.globalData || init.data || init);
    if (g && (g.tempModel || g.offerTitle)) {
      const tm = g.tempModel || {};
      const sku = g.skuModel || {};
      const props = sku.skuProps || [];
      const pr = (re) => props.find((p) => re.test(p.prop));
      const rangP = pr(/颜色|色|color/i) || props[0];
      const olP = props.find((p) => p !== rangP);
      const ranglar = rangP ? rangP.value.map((v) => v.name) : [];
      const olchamlar = olP ? olP.value.map((v) => v.name) : [];
      const map = sku.skuInfoMap || {};
      const variantlar = Object.keys(map).map((k) => {
        const [a, b] = k.split(/&gt;|>/);
        return { rang: a, olcham: b, narx_yuan: Number(map[k].price || map[k].discountPrice) || 0, qoldiq: map[k].canBookCount };
      }).filter((v) => v.narx_yuan);
      const ranges = (((g.orderParamModel || {}).orderParam || {}).skuParam || {}).skuRangePrices || [];
      const narxlar = ranges.map((r) => Number(r.price)).filter(Boolean);
      const imgs = (g.images || []).map((x) => ({ src: x.fullPathImageURI || x.imageURI || x.size310x310ImageURI, ...(x.zsFlags || {}) }));
      return natija("1688", {
        nom: tm.offerTitle || g.offerTitle,
        tavsif: g.description || "",
        narx: narxlar.length ? Math.max(...narxlar) : variantlar[0]?.narx_yuan || sonOl(matn(birinchi(".price-text", ".price"))),
        oraliq: narxlar.length > 1 ? [Math.min(...narxlar), Math.max(...narxlar)] : undefined,
        min: tm.beginAmount || (ranges[0] && ranges[0].beginAmount),
        dokon: tm.companyName,
        turkum: tm.categoryName,
        xus: (g.featureAttributes || g.attributes || []).map((a) => ({ k: a.name, v: (a.values || [a.value]).join(", ") })),
        ranglar, olchamlar,
        variantlar: new Set(variantlar.map((v) => v.narx_yuan)).size > 1 ? variantlar : [],
        rasmlar: imgs,
        olchamJadval: g.sizeChart || undefined,
        ogirlik: g.unitWeight,
      });
    }
    // DOM (yangi 1688 sahifalari)
    const nom = matn(birinchi(".title-text", ".d-title", "h1", '[class*="title-content"]'));
    if (!nom) return null;
    const xus = [...document.querySelectorAll(".offer-attr-item, .obj-content tr, .ant-descriptions-row")].flatMap((r) => {
      const n = r.querySelector(".offer-attr-item-name, td:first-child, th");
      const v = r.querySelector(".offer-attr-item-value, td:nth-child(2), td");
      return n && v ? [{ k: matn(n), v: matn(v) }] : [];
    });
    return natija("1688", {
      nom,
      narx: sonOl(matn(birinchi(".price-text", ".price-now", '[class*="price"]'))),
      rasmlar: yagona([...document.querySelectorAll(".detail-gallery-turn img, .detail-gallery img, .tab-trigger img, .img-list img")].map((i) => i.dataset.lazySrc || i.src)),
      xus,
      ishonch: "orta",
    });
  }

  // -------------------------------------------------------- Taobao / Tmall
  function sTaobao() {
    const nom = matn(birinchi('[class*="mainTitle"]', '[class*="ItemHeader--mainTitle"]', ".tb-main-title", "h1"));
    if (!nom) return null;
    const narx = sonOl(matn(birinchi('[class*="Price--priceText"]', '[class*="priceText"]', ".tb-rmb-num", '[class*="price"]')));
    const rasmlar = yagona([...document.querySelectorAll('[class*="PicGallery"] img, [class*="thumbnail"] img, #J_UlThumb img')].map((i) => i.src));
    const skuGr = [...document.querySelectorAll('[class*="skuItemWrapper"], [class*="SkuContent--skuItem"], .J_Prop')];
    const guruh = skuGr.map((g) => ({
      nom: matn(g.querySelector('[class*="ItemLabel"], [class*="labelText"], dt')),
      qiymat: [...g.querySelectorAll('[class*="valueItemText"], [class*="skuValueName"], li span')].map(matn).filter(Boolean),
    }));
    const rang = guruh.find((g) => /颜色|色/.test(g.nom)) || guruh[0];
    const ol = guruh.find((g) => g !== rang);
    const xus = [...document.querySelectorAll('[class*="infoItem--"], [class*="emphasisParamsInfoItem"], #J_AttrUL li')].map((li) => {
      const t = matn(li);
      const [k, ...v] = t.split(/[:：]/);
      const kk = li.querySelector('[class*="infoItemTitle"], [class*="Title"]');
      const vv = li.querySelector('[class*="infoItemContent"], [class*="SubTitle"]');
      return kk && vv ? { k: matn(kk), v: matn(vv) } : { k: (k || "").trim(), v: v.join(":").trim() };
    });
    return natija("taobao", {
      nom, narx,
      dokon: matn(birinchi('[class*="shopName"]', ".tb-shop-name", ".slogo-shopname")),
      rasmlar: rasmlar.length ? rasmlar : kattaRasmlar(),
      ranglar: rang ? rang.qiymat : [], olchamlar: ol ? ol.qiymat : [],
      xus,
      ishonch: rasmlar.length ? "yuqori" : "orta",
    });
  }

  // ------------------------------------------------------------ AliExpress
  function sAli() {
    const run = skriptJson(/window\.runParams\s*=\s*\{[\s\S]*?data:\s*(\{[\s\S]*\})\s*\}\s*;?/);
    if (run && run.titleModule) {
      const sku = (run.skuModule && run.skuModule.productSKUPropertyList) || [];
      const rang = sku.find((p) => /colou?r|цвет/i.test(p.skuPropertyName)) || sku[0];
      const ol = sku.find((p) => p !== rang);
      return natija("aliexpress", {
        nom: run.titleModule.subject,
        narx: sonOl(run.priceModule && (run.priceModule.formatedActivityPrice || run.priceModule.formatedPrice)),
        rasmlar: (run.imageModule && run.imageModule.imagePathList) || [],
        dokon: run.storeModule && run.storeModule.storeName,
        xus: ((run.specsModule && run.specsModule.props) || []).map((p) => ({ k: p.attrName, v: p.attrValue })),
        ranglar: rang ? rang.skuPropertyValues.map((v) => v.propertyValueDisplayName) : [],
        olchamlar: ol ? ol.skuPropertyValues.map((v) => v.propertyValueDisplayName) : [],
      });
    }
    const nom = matn(birinchi('h1[data-pl="product-title"]', '[class*="title--wrap"] h1', ".product-title-text", "h1"));
    if (!nom) return null;
    const guruh = [...document.querySelectorAll('[class*="sku-item--property"], .sku-property')].map((g) => ({
      nom: matn(g.querySelector('[class*="sku-item--title"], .sku-title')),
      qiymat: [...g.querySelectorAll('[class*="sku-item--image"] img, [class*="sku-item--text"], .sku-property-text')].map((x) => x.alt || matn(x)).filter(Boolean),
    }));
    return natija("aliexpress", {
      nom,
      narx: sonOl(matn(birinchi('[class*="price--current"]', ".product-price-value", '[class*="price-default--current"]'))),
      rasmlar: yagona([...document.querySelectorAll('[class*="slider--img"] img, [class*="image-view--previewBox"] img, .images-view-item img')].map((i) => i.src)),
      ranglar: guruh[0] ? guruh[0].qiymat : [],
      olchamlar: guruh[1] ? guruh[1].qiymat : [],
      xus: [...document.querySelectorAll('[class*="specification--prop"], .product-prop')].map((r) => ({ k: matn(r.querySelector('[class*="title"], .property-title')), v: matn(r.querySelector('[class*="desc"], .property-desc')) })),
      ishonch: "orta",
    });
  }

  // ------------------------------------------------------------ Pinduoduo
  function sPdd() {
    const raw = skriptJson(/window\.rawData\s*=\s*(\{[\s\S]*?\});\s*(?:window|<\/script>|$)/);
    const goods = raw && raw.store && raw.store.initDataObj && raw.store.initDataObj.goods;
    if (goods) {
      const skus = goods.skus || [];
      const specs = (i) => yagona(skus.map((s) => s.specs && s.specs[i] && s.specs[i].spec_value));
      return natija("pinduoduo", {
        nom: goods.goodsName,
        tavsif: goods.goodsDesc,
        narx: (goods.minGroupPrice || goods.minOnSaleGroupPrice || 0) / 100 || sonOl(goods.minGroupPrice),
        rasmlar: (goods.topGallery || goods.detailGallery || []).map((x) => (typeof x === "string" ? x : x.url)),
        dokon: raw.store.initDataObj.mall && raw.store.initDataObj.mall.mallName,
        ranglar: specs(0), olchamlar: specs(1),
        xus: (goods.goodsProperty || []).map((p) => ({ k: p.key, v: (p.values || []).join(", ") })),
      });
    }
    const nom = matn(birinchi(".enable-select", '[class*="goods-name"]', "h1"));
    if (!nom) return null;
    return natija("pinduoduo", { nom, narx: sonOl(matn(birinchi('[class*="price"]'))), rasmlar: kattaRasmlar(), ishonch: "orta" });
  }

  // ------------------------------------------------------------- umumiy
  function sUmumiy(sayt) {
    const ld = jsonLdProduct();
    const og = (p) => (document.querySelector(`meta[property="og:${p}"], meta[name="og:${p}"]`) || {}).content;
    const nom = (ld && ld.name) || og("title") || matn(document.querySelector("h1")) || document.title;
    if (!nom) return null;
    const offer = ld && (Array.isArray(ld.offers) ? ld.offers[0] : ld.offers);
    const ldImg = ld ? (Array.isArray(ld.image) ? ld.image : [ld.image]).map((x) => (typeof x === "string" ? x : x && x.url)) : [];
    const narxMatn = (document.body.innerText.match(/[¥￥]\s?(\d+(?:[.,]\d+)?)/) || [])[1];
    return natija(sayt, {
      nom,
      tavsif: (ld && ld.description) || og("description") || "",
      narx: sonOl(offer && (offer.price || offer.lowPrice)) || sonOl(narxMatn) || 0,
      rasmlar: yagona([...ldImg, og("image"), ...kattaRasmlar()]),
      dokon: ld && ld.brand && (ld.brand.name || ld.brand),
      xus: ((ld && ld.additionalProperty) || []).map((p) => ({ k: p.name, v: String(p.value) })),
      ishonch: ld ? "orta" : "past",
    });
  }

  function saytAniqla() {
    const h = location.hostname, p = location.pathname;
    if (/1688\.com$/.test(h) || /\/demo\/1688/.test(p)) return "1688";
    if (/taobao\.com$|tmall\.com$/.test(h)) return "taobao";
    if (/aliexpress\./.test(h)) return "aliexpress";
    if (/yangkeduo\.com$|pinduoduo\.com$/.test(h)) return "pinduoduo";
    return "boshqa";
  }

  /** Kirish sahifasimi (sayt mahsulotni ko'rsatish o'rniga loginga yubordi). */
  function kirishSahifasimi() {
    const h = location.hostname + location.pathname;
    return /login\.(1688|taobao|tmall|aliexpress)|passport\.|\/login|\/member\/login/.test(h) ||
      (!!document.querySelector('input[type="password"]') && !document.querySelector("h1, .title-text"));
  }

  globalThis.__zsSayt = saytAniqla;
  globalThis.__zsMahsulotSahifami = function () {
    const s = saytAniqla(), u = location.href;
    if (s === "1688") return /detail\.1688\.com\/offer|\/demo\/1688|offer\/\d+/.test(u);
    if (s === "taobao") return /item\.htm|detail\.tmall|item\.taobao/.test(u);
    if (s === "aliexpress") return /\/item\//.test(u);
    if (s === "pinduoduo") return /goods/.test(u);
    return !!jsonLdProduct();
  };

  globalThis.__zsAjrat = async function () {
    if (kirishSahifasimi()) return { xato: "kirish", matn: "Sayt kirishni talab qilyapti. Brauzerda shu saytga kiring va qayta urining." };
    const sayt = saytAniqla();
    const yollar = { "1688": s1688, taobao: sTaobao, aliexpress: sAli, pinduoduo: sPdd };
    let r = null;
    try { r = yollar[sayt] ? yollar[sayt]() : null; } catch (e) { r = null; }
    if (!r || !r.nom_asl) {
      try { r = sUmumiy(sayt); } catch { r = null; }
    }
    if (!r || !r.nom_asl) return { xato: "topilmadi", matn: "Sahifada mahsulot ma'lumoti topilmadi." };
    if (!r.rasmlar.length) r.ishonch = "past";
    return r;
  };
})();
