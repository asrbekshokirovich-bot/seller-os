/**
 * ZumSavdo kengaytmasi — Xitoy sahifasidagi «ZumSavdo'ga olish» tugmasi.
 * 1688, Taobao/Tmall, AliExpress, Pinduoduo mahsulot sahifalarida chiqadi.
 * Ajratish: src/ajratish.js (shu skriptdan oldin yuklanadi).
 */
(function () {
  if (window.__zsManba || window.top !== window) return;
  window.__zsManba = true;

  const CSS = `
  :host { all: initial; }
  .w { position: fixed; right: 20px; bottom: 24px; z-index: 2147483646; font: 600 14px/1.3 Inter, "Segoe UI", system-ui, sans-serif; display: flex; flex-direction: column; align-items: flex-end; gap: 8px; }
  .b { display: inline-flex; align-items: center; gap: 9px; height: 48px; padding: 0 18px 0 8px; border-radius: 99px; border: 0; cursor: pointer; background: #0a1a34; color: #fff; box-shadow: 0 8px 28px rgba(10,26,52,.35); font: inherit; transition: transform .12s; }
  .b:hover { transform: translateY(-1px); }
  .b:disabled { cursor: default; opacity: .9; }
  .m { width: 34px; height: 34px; border-radius: 50%; background: #d4e94c; color: #0a1a34; display: grid; place-items: center; font-weight: 900; font-size: 17px; flex: none; }
  .t { background: #fff; color: #0a1a34; border-radius: 14px; padding: 12px 14px; box-shadow: 0 8px 28px rgba(10,26,52,.22); max-width: 300px; font-weight: 500; font-size: 13px; display: none; border: 1px solid #e3e7ee; }
  .t.on { display: block; }
  .t b { display: block; margin-bottom: 4px; font-size: 14px; }
  .t a { color: #1a3a6c; font-weight: 700; cursor: pointer; text-decoration: underline; }
  .t.ok b { color: #137a3f; }
  .t.bad b { color: #b42318; }
  .x { position: absolute; top: -6px; right: -6px; width: 20px; height: 20px; border-radius: 50%; border: 0; background: #52627a; color: #fff; font-size: 12px; cursor: pointer; display: none; }
  .w:hover .x { display: block; }
  .s { width: 16px; height: 16px; border-radius: 50%; border: 2px solid rgba(10,26,52,.25); border-top-color: #0a1a34; animation: r .7s linear infinite; }
  @keyframes r { to { transform: rotate(360deg); } }
  `;

  function ishga() {
    if (!globalThis.__zsMahsulotSahifami || !globalThis.__zsMahsulotSahifami()) return false;
    if (document.getElementById("zumsavdo-manba")) return true;
    const host = document.createElement("div");
    host.id = "zumsavdo-manba";
    const sh = host.attachShadow({ mode: "open" });
    sh.innerHTML = `<style>${CSS}</style><div class="w"><div class="t" id="t"></div><div style="position:relative"><button class="b" id="b"><span class="m" id="m">Z</span><span id="l">ZumSavdo'ga olish</span></button><button class="x" id="x" title="Yashirish">×</button></div></div>`;
    document.documentElement.appendChild(host);
    const $ = (id) => sh.getElementById(id);
    const tost = (tur, sarlavha, matn, havola) => {
      const t = $("t");
      t.className = "t on " + tur;
      t.innerHTML = "";
      const b = document.createElement("b"); b.textContent = sarlavha; t.appendChild(b);
      if (matn) t.appendChild(document.createTextNode(matn + " "));
      if (havola) {
        const a = document.createElement("a"); a.textContent = havola.matn; a.onclick = havola.f; t.appendChild(a);
      }
    };
    $("x").onclick = () => host.remove();
    $("b").onclick = async () => {
      const { sessiya } = await chrome.storage.local.get("sessiya");
      const b = $("b");
      b.disabled = true;
      $("m").innerHTML = '<span class="s"></span>';
      $("l").textContent = "Olinmoqda…";
      try {
        const xom = await globalThis.__zsAjrat();
        if (!xom || xom.xato) {
          tost("bad", "Olib bo'lmadi", (xom && xom.matn) || "Mahsulot ma'lumoti topilmadi.");
          return;
        }
        await chrome.runtime.sendMessage({ tur: "xomQosh", xom });
        if (sessiya) {
          tost("ok", "Studiyaga qo'shildi ✓", `«${xom.nom_asl.slice(0, 40)}…» — ${xom.rasmlar.length} ta rasm.`, {
            matn: "Studiyani ochish", f: () => chrome.runtime.sendMessage({ tur: "studiyaOch" }),
          });
        } else {
          tost("ok", "Saqlandi", "ZumSavdo'ga kirganingizda Studiyada paydo bo'ladi.", {
            matn: "ZumSavdo'ni ochish", f: () => chrome.runtime.sendMessage({ tur: "studiyaOch" }),
          });
        }
        if (xom.ishonch === "past") tost("ok", "Studiyaga qo'shildi", "Sahifa tuzilishi notanish — ma'lumotni Studiyada tekshiring.", { matn: "Ochish", f: () => chrome.runtime.sendMessage({ tur: "studiyaOch" }) });
      } catch (e) {
        tost("bad", "Xatolik", e.message || "Kengaytma qayta yuklandi — sahifani yangilang.");
      } finally {
        b.disabled = false;
        $("m").textContent = "Z";
        $("l").textContent = "ZumSavdo'ga olish";
      }
    };
    return true;
  }

  // SPA saytlarda sahifa almashadi — kuzatib turamiz.
  let urinish = 0;
  const t = setInterval(() => { if (ishga() || ++urinish > 20) clearInterval(t); }, 800);
  ishga();
  let oxirgi = location.href;
  setInterval(() => {
    if (location.href !== oxirgi) {
      oxirgi = location.href;
      const h = document.getElementById("zumsavdo-manba");
      if (h && !globalThis.__zsMahsulotSahifami()) h.remove();
      else ishga();
    }
  }, 1000);
})();
