// ZumSavdo kengaytmasi — popup: ulanish holati, tanga, tezkor amallar.
const $ = (id) => document.getElementById(id);
const fonga = (x) => chrome.runtime.sendMessage(x);
const SAYT_NOM = { "1688": "1688", taobao: "Taobao", aliexpress: "AliExpress", pinduoduo: "Pinduoduo", boshqa: "Sayt" };

async function chiz() {
  const { sessiya, tarix = [], xomlar = [] } = await chrome.storage.local.get(["sessiya", "tarix", "xomlar"]);
  $("ver").textContent = "Versiya " + chrome.runtime.getManifest().version;
  if (sessiya) {
    $("st").className = "st on";
    $("stm").textContent = "Ulangan: " + (sessiya.ism || sessiya.telefon);
    $("kim").textContent = sessiya.telefon;
    $("tanga").hidden = false;
    $("tanga").textContent = "● " + sessiya.tanga;
    $("bog").open = false;
  } else {
    $("st").className = "st";
    $("stm").textContent = "Ulanmagan — ZumSavdo saytiga kiring";
    $("bog").open = true;
  }
  const t = $("tarix");
  t.innerHTML = "";
  if (tarix.length) {
    const l = document.createElement("div");
    l.className = "lbl";
    l.textContent = "Oxirgi olinganlar" + (xomlar.length ? ` · ${xomlar.length} ta Studiyaga yuborilmoqda` : "");
    t.append(l);
    for (const x of tarix.slice(0, 4)) {
      const r = document.createElement("div");
      r.className = "t";
      const im = document.createElement("img");
      if (x.rasm) im.src = x.rasm;
      const s = document.createElement("span");
      const b = document.createElement("b"); b.textContent = x.nom;
      const sm = document.createElement("small"); sm.textContent = `${SAYT_NOM[x.sayt] || x.sayt} · ${new Date(x.vaqt).toLocaleString("ru-RU")}`;
      s.append(b, sm);
      r.append(im, s);
      t.append(r);
    }
  }
}

$("och").onclick = () => { fonga({ tur: "studiyaOch" }); window.close(); };

$("ol").onclick = async () => {
  $("ol").disabled = true;
  $("olm").className = "msg";
  $("olm").textContent = "Olinmoqda…";
  const r = await fonga({ tur: "sahifadanOl" });
  $("ol").disabled = false;
  if (r && r.ok) {
    $("olm").className = "msg ok";
    $("olm").textContent = "✓ Studiyaga qo'shildi: " + r.nom.slice(0, 60);
    chiz();
  } else {
    $("olm").className = "msg bad";
    $("olm").textContent = (r && r.xato) || "Olib bo'lmadi";
  }
};

$("kodb").onclick = async () => {
  const kod = $("kod").value.replace(/\D/g, "");
  if (kod.length !== 6) { $("kodm").className = "msg bad"; $("kodm").textContent = "Kod 6 ta raqamdan iborat"; return; }
  $("kodm").className = "msg"; $("kodm").textContent = "Tekshirilmoqda…";
  const r = await fonga({ tur: "kodYubor", kod });
  if (r && r.ok) { $("kodm").className = "msg ok"; $("kodm").textContent = "✓ Bog'landi"; setTimeout(chiz, 600); }
  else { $("kodm").className = "msg bad"; $("kodm").textContent = (r && r.xato) || "Bog'lanmadi"; }
};

chrome.storage.onChanged.addListener(chiz);
chiz();
