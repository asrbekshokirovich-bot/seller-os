// src/background.ts
var BACKEND_URL = "https://duequijnnzcngzzvjqst.supabase.co/functions/v1/selleros";
var ANON_KEY = "sb_publishable_KzLAuxJYrA66iD4lMp7V-g_1GYLuNzL";
var SESSIYA_KALITI = "sessiya";
function sarlavhalar(token) {
  const h = {
    apikey: ANON_KEY,
    Authorization: `Bearer ${ANON_KEY}`,
    "Content-Type": "application/json"
  };
  if (token) h["x-sessiya"] = token;
  return h;
}
async function sessiyaOl(yangidan = false) {
  if (!yangidan) {
    const saqlangan = await chrome.storage.local.get(SESSIYA_KALITI);
    const token = saqlangan[SESSIYA_KALITI];
    if (typeof token === "string" && token) return token;
  }
  const javob = await fetch(`${BACKEND_URL}/sessiya`, {
    method: "POST",
    headers: sarlavhalar(),
    body: "{}"
  });
  if (!javob.ok) return null;
  const data = await javob.json();
  if (!data.token) return null;
  await chrome.storage.local.set({ [SESSIYA_KALITI]: data.token });
  return data.token;
}
async function xitoyQidir(productId) {
  let token = await sessiyaOl();
  if (!token) return { xato: "sessiya ochilmadi" };
  const sorov = (t) => fetch(`${BACKEND_URL}/xitoy-qidiruv`, {
    method: "POST",
    headers: sarlavhalar(t),
    body: JSON.stringify({ productId })
  });
  let javob = await sorov(token);
  if (javob.status === 401) {
    token = await sessiyaOl(true);
    if (!token) return { xato: "sessiya ochilmadi" };
    javob = await sorov(token);
  }
  const data = await javob.json().catch(() => null);
  if (!data) return { xato: `javob o\u02BBqilmadi (HTTP ${javob.status})` };
  return data;
}
chrome.runtime.onMessage.addListener((xabar, _yuboruvchi, javobBer) => {
  if (xabar?.tur !== "xitoy-qidiruv") return false;
  xitoyQidir(Number(xabar.productId)).then(javobBer).catch((e) => javobBer({ xato: String(e?.message ?? e) }));
  return true;
});
