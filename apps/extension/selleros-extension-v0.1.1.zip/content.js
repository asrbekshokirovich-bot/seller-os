"use strict";
(() => {
  // src/content.ts
  var TUGMA_ID = "selleros-xitoy-tugma";
  function tovarIdOl() {
    const mos = window.location.pathname.match(/\/product\/(\d+)/);
    return mos ? Number(mos[1]) : null;
  }
  function tugmaYarat() {
    const tugma = document.createElement("button");
    tugma.id = TUGMA_ID;
    tugma.textContent = "Xitoydan top";
    tugma.title = "Seller OS: 1688 dan o\u02BBxshash tovarlarni topish";
    tugma.addEventListener("click", async () => {
      const pid = tovarIdOl();
      if (!pid) {
        tugma.textContent = "Tovar topilmadi";
        return;
      }
      tugma.textContent = "Qidirilmoqda...";
      tugma.disabled = true;
      try {
        const javob = await chrome.runtime.sendMessage({
          tur: "xitoy-qidiruv",
          productId: pid
        });
        if (!javob) {
          tugma.textContent = "Javob kelmadi";
        } else if (javob.xato) {
          tugma.textContent = `Xato: ${javob.xato}`;
        } else if (javob.natijalar?.length) {
          tugma.textContent = `${javob.natijalar.length} ta topildi`;
          natijalarniKorsat(javob.natijalar);
        } else if (javob.izoh) {
          tugma.textContent = javob.izoh;
        } else {
          tugma.textContent = "Natija topilmadi";
        }
      } catch (e) {
        tugma.textContent = `Xato: ${e?.message ?? "noma\u02BClum"}`;
      } finally {
        tugma.disabled = false;
      }
    });
    return tugma;
  }
  function natijalarniKorsat(natijalar) {
    let panel = document.getElementById("selleros-xitoy-panel");
    if (panel) panel.remove();
    panel = document.createElement("div");
    panel.id = "selleros-xitoy-panel";
    const sarlavha = document.createElement("h3");
    sarlavha.textContent = "1688 natijalar";
    panel.appendChild(sarlavha);
    for (const n of natijalar) {
      const qator = document.createElement("div");
      qator.className = "selleros-natija";
      const rasm = document.createElement("img");
      rasm.src = n.rasmUrl;
      rasm.alt = n.title;
      qator.appendChild(rasm);
      const matn = document.createElement("div");
      matn.className = "selleros-natija-matn";
      matn.innerHTML = `
      <strong>${escapeHtml(n.title)}</strong>
      <span>\xA5${n.narxYuan}</span>
      <span>MOQ: ${n.moq}</span>
    `;
      qator.appendChild(matn);
      panel.appendChild(qator);
    }
    const tugma = document.getElementById(TUGMA_ID);
    tugma?.parentElement?.insertBefore(panel, tugma.nextSibling);
  }
  function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = s;
    return d.innerHTML;
  }
  function joylashtir() {
    if (document.getElementById(TUGMA_ID)) return;
    if (!tovarIdOl()) return;
    const joy = document.querySelector('[data-testid="product-actions"], .product-actions, .product-page');
    if (joy) {
      joy.appendChild(tugmaYarat());
    }
  }
  var kuzatuvchi = new MutationObserver(() => joylashtir());
  kuzatuvchi.observe(document.body, { childList: true, subtree: true });
  joylashtir();
})();
